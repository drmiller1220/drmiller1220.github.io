# load required packages
library(data.table)
library(lme4)

# set your working directory
setwd("...")

# load in our "toy" data set
final_df <- fread("final_df_sample.csv", header = TRUE, stringsAsFactors = FALSE)

# Prelims

# get a sense of the data
## summary statistics of variables
summary(final_df)
## how many unique interest groups?
length(unique(final_df$IGName))
## how many unique time periods?
length(unique(final_df$YearQuarter))

# what does the data look like?
## let's look at some of the data for Amazon
head(final_df[which(final_df$IGName=="Amazon.com"),], n=10)

#############################################################################################

# Hypothesis 1: Interest groups with higher lobbying expenditures have more WH visits

# Start by using OLS to test this; include fixed effects for IGs and time periods

ols_model <- lm(num_visits ~ num_visits1l + lobbyexp1l + as.factor(IGName) + 
                  as.factor(YearQuarter), data = final_df)
summary(ols_model)

# we reject the null; higher levels of lobbying expenditures are associated with more
# WH visits

# Should we be using OLS?  One glaring issue is that we are not accounting for the nested
# data structure
### Put differently, we assume all observations are independent, but there are multiple
### observations for each IG and each time period, such that we violate the IID assumption

# Switch to a multilevel model; here, we can explicitly model the nestedness of the data

# lmer syntax: similar to lm, different only with respect to specifying varying intercepts
# and slopes.  To include varying intercepts but NOT varying slopes, include as a term
# in the regression formula "(1|[name of variable for which you want varying intercepts])".
# Here, we include varying intercepts for IGs and time periods

lmer_model <- lmer(num_visits ~ num_visits1l + lobbyexp1l + (1|IGName) + (1|YearQuarter), 
                   data = final_df)
summary(lmer_model)

# how do we interpret this output?
### fixed effects are our observation-specific covariates, lagged visits and expenditures;
### interpret these as you would in a regular lm
### random effects are our grouping variables; the variance/sd relates to the variance/sd of
### the varying coefficients (i.e., what is the variance of the IG-specific intercepts)
### correlation of fixed effects; you can ignore this

# if we wanted to extract the varying intercepts:
as.data.frame(cbind(rownames(coef(lmer_model)[[1]]), coef(lmer_model)[[1]][,1]))

# One way to interpret the "usefulness" of using a multilevel structure, and of the
# groupings you are using in your model, is to look at the "intraclass correlation" (ICC).
# We calculate the ICC as the variance of a specific grouping's varying intercepts/slopes
# divided by the sum of the residual variance and the variance of that same grouping's
# varying intercepts/slopes.  The ICC ranges from 0 to 1, where 0 indicates that the grouping
# explains no information and 1 if all observations in each group are identical

# So, for the IG varying intercepts:
vary_inter_mat <- as.data.frame(VarCorr(lmer_model))
vary_inter_mat$vcov[1] / (vary_inter_mat$vcov[1] + vary_inter_mat$vcov[3])

# And for time periods
vary_inter_mat$vcov[2] / (vary_inter_mat$vcov[2] + vary_inter_mat$vcov[3])

# Clearly, the IG varying intercepts do more to explain variation than do the time period
# intercepts

# Let's say we wanted to test a new hypothesis: More liberal IGs have more WH visits.

# In an ordinary linear regression, we could not include group-level measures of ideology
# AND group-level fixed effects, but we can in a multilevel model; the group-level
# predictors help in the estimation of the group-level intercepts (i.e., groups sharing
# characteristics will have more similar intercepts)

# in lmer syntax, we include group-level predictors as standard covariates; the reason
# why is a little complicated, but we can discuss

lmer_model_cf <- lmer(num_visits ~ num_visits1l + lobbyexp1l + CFscore + (1|IGName) + 
                        (1|YearQuarter), data = final_df)
summary(lmer_model_cf)

# we reject the null for our hypothesis; more liberal groups get more WH visits (the CFscores
# are coded such that liberal groups have negative scores and conservative groups have
# positive scores)

##########################################################################################

# BONUS MATERIAL

# What if we thought that the effect of lobbying expenditures on the number of WH visits
# varies by IG?  We can allow for this possibility by varying the slope of lobbying expenditures
# by IG as follows:

lmer_model_vary_slope <- lmer(num_visits ~ num_visits1l + lobbyexp1l + CFscore + 
                                lobbyexp1l:CFscore +
                                (1 + lobbyexp1l|IGName) + (1|YearQuarter), data = final_df)
# the explanation for why we need to include the interaction between lobbying expenditures
# and CF scores is a little complicated; we can discuss it
# note: if you ONLY wanted to vary the slope and not the intercept, change "1 +" to "0 +"
summary(lmer_model_vary_slope)

